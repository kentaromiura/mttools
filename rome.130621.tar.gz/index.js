(function(res) {
	if (typeof module !== "undefined") {
		module.exports = res;
	}
	return res;
})(
(function(global) {
  'use strict';
  // uid://project-rome/rome/index.ts
	const ___R$project$rome$rome$index_ts = {};


  return ___R$project$rome$rome$index_ts;
})(typeof global !== 'undefined' ? global : typeof window !== 'undefined' ? window : this));
//# sourceMappingURL=index.js.map